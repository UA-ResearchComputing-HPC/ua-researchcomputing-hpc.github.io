#!/usr/bin/env python3

import os, time
from multiprocessing import Pool

num_cpus=int(os.environ["SLURM_CPUS_ON_NODE"])
print("Running a pool with %s workers"%num_cpus)

def f(x):
    # The sleep will allow us to get a sense of the speedup given by using multiprocessing
    time.sleep(1)
    return x*x

if __name__=="__main__":
    with Pool(num_cpus) as p:
        data = range(1,1000)
        # p.map takes an interable, maps it onto a function, and executes the processes
        # distributed over the allocated CPUs using the pool of workers
        output = p.map(f,data)
