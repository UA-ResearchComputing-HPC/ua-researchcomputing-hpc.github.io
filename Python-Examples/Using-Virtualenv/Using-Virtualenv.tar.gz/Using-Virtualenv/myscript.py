#!/usr/bin/env python3

import os

def in_venv():
    try:
        os.environ["VIRTUAL_ENV"]
        return True
    except KeyError:
        return False

virtualenv = in_venv()
if virtualenv == True:
    import emoji
    print(emoji.emojize(":floppy_disk: Using a virtual environment! :floppy_disk:"))
else:
    print("Not using a virtual environment, let's check if we can import emoji")
    try:
        import emoji
    except ImportError:
        print("oops, can't import emoji!")


