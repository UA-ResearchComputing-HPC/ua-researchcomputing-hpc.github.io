#!/usr/bin/env python3

import sys, os


print("\n ===== In Python Script =====\n")
print("Hello World!")
print("The python being used to execute this script is in: %s" %os.path.dirname(sys.executable))
print("The version of python being used is: %s"%sys.version)
print("\n == Leaving Python Script ===\n")
# Want your output printed before the job ends? Use a flush statement:
sys.stdout.flush()

