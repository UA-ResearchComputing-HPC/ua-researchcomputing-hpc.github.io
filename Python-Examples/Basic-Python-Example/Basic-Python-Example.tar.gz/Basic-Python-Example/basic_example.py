#!/usr/bin/env python3

import sys, os


print("\n ===== In Python Script =====\n")
print("The python being used to execute this script is in: %s" %os.path.dirname(sys.executable))
print("The version of python being used is: %s"%sys.version)
# Want your output printed before the job ends? Use a flush statement:
sys.stdout.flush()

# Did you pass variables into the script, e.g. using "python3 <script> [arg]"?
print("\nChecking if any varibles have been passed to the script")
try:
    input_var = sys.argv[1]
except IndexError:
    input_var = None
if input_var == None:
    print("Guess not, oh well!")
else:
    print("Looks like you've included the input variable: %s"%input_var)

print("\nLet's also grab some environment variables")
print("We're running on node: %s"%os.environ["SLURM_NODELIST"])
print("Our SLURM Job ID is: %s"%os.environ["SLURM_JOB_ID"])

print("\n===== Leaving Python Script =====\n")
