#!/usr/bin/env python3

import time
import torch
import torch.nn as nn
from torchvision import datasets, models, transforms
from torch.utils.data import Dataset, DataLoader, random_split
from torcheval.metrics.functional import multiclass_accuracy

class DatasetFromSubset(Dataset):
    def __init__(self, subset, transform=None):
        super(Dataset, self).__init__()
        self.subset = subset
        self.transform = transform

    def __getitem__(self, index):
        x, y = self.subset[index]
        if self.transform:
            x = self.transform(x)
        return x, y

    def __len__(self):
        return len(self.subset)

def get_dls(bs):
    root = "data/" # This is where the data will be downloaded
    dsets = datasets.FashionMNIST(root=root, download=True, train=True)
    train_set, valid_set = random_split(dsets, [0.8, 0.2])
    mean = dsets.data[train_set.indices].float().mean()
    std = dsets.data[train_set.indices].float().std()
    tfms = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize((mean / 255,), (std / 255,))
    ])
    train_dl = DataLoader(
        DatasetFromSubset(train_set, transform=tfms),
        batch_size=bs,
        shuffle=True,
        **kwargs,
    )
    valid_dl = DataLoader(
        DatasetFromSubset(valid_set, transform=tfms),
        batch_size=2 * bs,
        shuffle=False,
        **kwargs,
    )
    test_dl = DataLoader(
        datasets.FashionMNIST(root=root, download=True, train=False, transform=tfms),
        batch_size=2 * bs,
        shuffle=True,
        **kwargs,
    )
    return train_dl, valid_dl, test_dl

def fit(epochs, model, loss_func, opt, train_dl, valid_dl):
    start_time = time.time()
    for epoch in range(epochs):
        model.train()
        for data in train_dl:
            xb, yb = data[0].to(device), data[1].to(device)
            loss = loss_func(model(xb), yb)
            loss.backward()
            opt.step()
            opt.zero_grad()
        valid_loss, valid_acc = predict_stats(valid_dl)
        print(f"Epoch {epoch + 1}/{epochs}, Validation loss: {valid_loss:.4f}, Validation accuracy: {valid_acc:.4f}")
    print(f"Training time: {time.time() - start_time:.4f}s")
    return valid_loss, valid_acc

def predict_stats(dl):
    model.eval()
    if device == torch.device("cuda"):
        torch.cuda.empty_cache()
    with torch.no_grad():
        tot_loss = tot_acc = count = 0
        for data in dl:
            xb, yb = data[0].to(device), data[1].to(device)
            pred = model(xb)
            n = len(xb)
            count += n
            tot_loss += loss_func(pred, yb).item() * n
            tot_acc += multiclass_accuracy(pred, yb).item() * n
        return tot_loss / count, tot_acc / count


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
kwargs = {"num_workers": 1, "pin_memory": True} if device==torch.device("cuda") else {}

train_dl, valid_dl, test_dl = get_dls(512)
    
model = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)
model.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
model.fc = nn.Linear(model.fc.in_features, 10)
model = model.to(device)

opt = torch.optim.Adadelta(model.parameters())
loss_func = nn.CrossEntropyLoss()

epochs = 5

fit(epochs, model, loss_func, opt, train_dl, valid_dl)

test_loss, test_acc = predict_stats(test_dl)
print(f"Test loss: {test_loss:.4f}, Test accuracy: {test_acc:.4f}")
