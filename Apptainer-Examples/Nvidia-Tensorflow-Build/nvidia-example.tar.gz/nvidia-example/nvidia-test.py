#!/usr/bin/env python3 

import tensorflow as tf
import astropy

print("Num GPUs Available: ", len(tf.config.list_physical_devices('GPU')))

