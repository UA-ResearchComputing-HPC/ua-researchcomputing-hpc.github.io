#!/usr/bin/env python3

import os

print("Hello world! I'm running on compute node: %s"%os.environ["HOSTNAME"])
