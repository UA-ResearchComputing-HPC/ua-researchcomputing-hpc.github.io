import sys, os, psutil, tracemalloc

n = 400000000
print("Finding primes less than %s"%n)
print('Program Executing\n')
sys.stdout.flush()
tracemalloc.start()
prime = [True for i in range(n+1)] 
p = 2
while (p * p <= n): 

    # If prime[p] is not changed, then it is a prime 
    if (prime[p] == True): 

        # Update all multiples of p 
        for i in range(p * p, n+1, p): 
            prime[i] = False
    p += 1
current,peak=tracemalloc.get_traced_memory()
print('Largest prime less than %s : '%n +[str(p) for p in range(2,n) if prime[p]][-1])
sys.stdout.flush()
# print memory
print(f"Current memory usage is {current / 10**6}MB; Peak was {peak / 10**6}MB\n")
