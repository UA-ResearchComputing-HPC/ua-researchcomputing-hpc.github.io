attach(mtcars)
jpeg("third_plot.jpg")
plot(wt, mpg, main="Third Plot Example Using Cars df",
   xlab="Car Weight ", ylab="Miles Per Gallon ", pch=19)
abline(lm(mpg~wt), col="red") # regression line (y~x)
lines(lowess(wt,mpg), col="blue") # lowess line (x,y)
